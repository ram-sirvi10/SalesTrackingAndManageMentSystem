package com.company.salestracker.service.impl;

import com.company.salestracker.service.DealService;

public class DealServiceImpl implements DealService {

}

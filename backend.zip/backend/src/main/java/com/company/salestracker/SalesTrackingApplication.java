package com.company.salestracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesTrackingApplication.class, args);
	}

}

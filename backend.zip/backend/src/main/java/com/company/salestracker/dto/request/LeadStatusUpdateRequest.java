package com.company.salestracker.dto.request;

public class LeadStatusUpdateRequest {

	private String status;

}

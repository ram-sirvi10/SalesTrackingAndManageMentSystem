package com.company.salestracker.entity;

public enum OtpType {
	RAGISTER, FORGOT_PASSWORD, RESET_PASSWORD ,LOGIN
}

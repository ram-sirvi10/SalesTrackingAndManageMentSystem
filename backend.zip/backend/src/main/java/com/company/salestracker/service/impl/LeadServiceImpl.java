package com.company.salestracker.service.impl;

public class LeadServiceImpl {

}

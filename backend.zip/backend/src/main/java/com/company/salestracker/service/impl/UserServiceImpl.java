package com.company.salestracker.service.impl;

import com.company.salestracker.service.UserService;

public class UserServiceImpl implements UserService {

}

package com.company.salestracker.security;

public class JwtAuthorizationFilter {

}

package com.company.salestracker.dto.response;

public class PermissionResponse {

	private String id;
	private String permissionCode;
	private String description;
}

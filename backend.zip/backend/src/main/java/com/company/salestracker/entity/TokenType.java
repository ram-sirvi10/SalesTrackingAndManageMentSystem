package com.company.salestracker.entity;

public enum TokenType {
	ACCESSTOKEN, AUTHTOKEN, REFRESHTOKEN
}

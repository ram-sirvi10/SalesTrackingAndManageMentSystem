package com.company.salestracker.entity;

public enum DealStage {
	NEGOTIATION , PROPOSAL , CLOSED_WON ,CLOSED_LOST 
}

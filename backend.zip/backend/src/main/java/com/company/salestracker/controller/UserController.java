package com.company.salestracker.controller;

public class UserController {

}

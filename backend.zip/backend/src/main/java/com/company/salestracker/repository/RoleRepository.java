package com.company.salestracker.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.company.salestracker.entity.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, String> {
	
//	@Query("select r.id from Role r")
//    List<String> findAllIds();
	
}

package com.company.salestracker.service.impl;

import com.company.salestracker.service.PermissionService;

public class PermissionServiceImpl implements PermissionService {

}

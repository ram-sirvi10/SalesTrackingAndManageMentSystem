package com.company.salestracker.dto.response;

public class OtpResponse {

}

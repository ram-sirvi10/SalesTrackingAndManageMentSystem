package com.company.salestracker.dto.request;

public class LeadRequest {

	
	private String name;
	
	
	private String email;
	
	
	private String phone;
	
	
	private String source;

	
}

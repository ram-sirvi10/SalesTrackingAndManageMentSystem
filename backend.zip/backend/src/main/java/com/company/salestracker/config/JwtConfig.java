package com.company.salestracker.config;

public class JwtConfig {

}

package com.company.salestracker.service.impl;

import com.company.salestracker.service.TargetService;

public class TargetServiceImpl implements TargetService {

}

package com.company.salestracker.dto.request;

import lombok.Data;

@Data
public class DealAssignRequest {
	private String dealId;
	private String userId;
}

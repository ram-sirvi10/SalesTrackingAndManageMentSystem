package com.company.salestracker.entity;

public enum LeadStatus {
	NEW , CONTACTED , QUALIFIED , LOST 

}

package com.company.salestracker.controller;

public class LeadController {

}

package com.company.salestracker.entity;

public enum PaymentStatus {
	PENDING,FAILED,SUCCESSFUL
}

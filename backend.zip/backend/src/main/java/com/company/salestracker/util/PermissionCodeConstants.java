package com.company.salestracker.util;

public class PermissionCodeConstants {
	public static final String UPDATE_USER = "UPDATE_USER";
	public static final String VIEW_ASSIGNED_LEAD_OF_OTHER_USER_ = "VIEW_ASSIGNED_LEAD_OF_OTHER_USER_";
	public static final String VIEW_ASSIGNED_DEAL_OF_OTHER_USER_ = "VIEW_ASSIGNED_DEAL_OF_OTHER_USER_";
	public static final String VIEW_SALES_OF_OTHER_USER_ = "VIEW_SALES_OF_OTHER_USER_";
}

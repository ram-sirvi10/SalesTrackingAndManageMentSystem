package com.company.salestracker.dto.response;

public class TargetResponse {

	private String id;
	private UserResponse user;
	private Integer targetMonth;
	private Integer targetYear;
	private Double targetAmount;
}

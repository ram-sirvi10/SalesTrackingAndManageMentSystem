package com.company.salestracker.dto.response;

import java.util.Set;

import com.company.salestracker.entity.Permission;

public class RoleResponse {

	
	private String roleName;


	private String description;
	
	
	private Set<PermissionResponse> permissions;
}
 
package com.company.salestracker.dto.request;

public class LeadAssignRequest {

	private String userId;

}

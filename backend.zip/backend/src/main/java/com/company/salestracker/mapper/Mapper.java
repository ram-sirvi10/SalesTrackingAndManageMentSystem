package com.company.salestracker.mapper;

import java.util.Set;

import com.company.salestracker.dto.request.UserRequest;
import com.company.salestracker.entity.Role;
import com.company.salestracker.entity.User;

public class Mapper {

	public static User toEntity(UserRequest request, Set<Role> roles) {
		return User.builder().name(request.getName()).email(request.getEmail()).phone(request.getPhone())
				.password(request.getPassword()).roles(roles).build();
	}

	public static void toResponse(User save) {
		// TODO Auto-generated method stub
		
	}

}

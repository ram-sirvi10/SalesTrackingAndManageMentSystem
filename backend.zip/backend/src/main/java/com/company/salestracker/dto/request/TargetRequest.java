package com.company.salestracker.dto.request;

public class TargetRequest {

	private String userId;
	private Integer targetMonth;
	private Integer targetYear;
	private Double targetAmount;
}

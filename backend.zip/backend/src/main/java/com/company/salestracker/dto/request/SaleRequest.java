package com.company.salestracker.dto.request;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class SaleRequest {

	@NotEmpty
	private String dealId;
	
	@NotEmpty
	private BigDecimal saleAmount;
	
	
	private String paymentStatus;

	@NotEmpty
	private LocalDate saleDate;
}

package com.company.salestracker.service.impl;

import com.company.salestracker.service.RoleService;

public class RoleServiceImpl implements RoleService {

}

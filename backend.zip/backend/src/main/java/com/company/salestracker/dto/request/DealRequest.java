package com.company.salestracker.dto.request;

public class DealRequest {

	public DealRequest() {
		// TODO Auto-generated constructor stub
	}

}

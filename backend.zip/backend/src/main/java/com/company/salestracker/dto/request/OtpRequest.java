package com.company.salestracker.dto.request;

public class OtpRequest {
	private String otp;
	private String otpType;
	private String authToken;
}

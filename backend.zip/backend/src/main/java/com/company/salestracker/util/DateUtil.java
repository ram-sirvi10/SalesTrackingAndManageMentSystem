package com.company.salestracker.util;

public class DateUtil {

	public DateUtil() {
		// TODO Auto-generated constructor stub
	}

}

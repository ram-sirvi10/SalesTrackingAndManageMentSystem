package com.company.salestracker.service;

public interface ReportService {

}

package com.company.salestracker.dto.request;

public class ForgotPasswordRequest {

}

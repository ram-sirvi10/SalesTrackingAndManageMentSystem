package com.company.salestracker.entity;

public enum UserStatus {
	ACTIVE,INACTIVE
}

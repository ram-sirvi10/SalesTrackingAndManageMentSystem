package com.company.salestracker.entity;

public enum UserStatus {
	PENDING,ACTIVE,INACTIVE, REJECTED
}

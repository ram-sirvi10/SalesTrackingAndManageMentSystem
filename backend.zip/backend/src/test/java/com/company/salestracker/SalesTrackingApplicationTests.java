package com.company.salestracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesTrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
